public class Program
{
    public static void main(String[] args)
    {
        Game game = new Game("Game", 400, 400);
        game.start();
        // game.stop();  

    }
}
 