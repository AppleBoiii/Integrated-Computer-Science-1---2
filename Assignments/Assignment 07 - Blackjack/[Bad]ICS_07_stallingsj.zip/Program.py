import numpy as np
import random as rand
import webbrowser as browser

def getDeck():
	
	deck = np.array([["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"],["A","2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"],["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"], ["A","2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]])
	height, width = deck.shape
	usedCards = np.ones((height, width), dtype = int)
	
	return deck, usedCards

def hit(deck, usedCards):
	
	height, width = deck.shape
	pickSuite = rand.randint(0, height-1)
	pickCard = rand.randint(0, width-1)
	
	while usedCards[pickSuite][pickCard] == 0:
		pickSuite = rand.randint(0, height-1)
		pickCard = rand.randint(0, width-1)
	
	card = deck[pickSuite][pickCard]
	usedCards[pickSuite][pickCard] = 0
	
	return card, usedCards

def showHand(playerHand):

	hand = ""
	
	for i in range(len(playerHand)-1):
		hand += f"{playerHand[i]}, "
	
	#strPrint = "Your cards are, "
	
	if len(playerHand) > 1:
		strPrint = "Cards are "
		hand += f"and {playerHand[len(playerHand)-1]}"
	else:
		strPrint = "Card is "
		hand += f"{playerHand[0]}"
		
	return hand
	
def handValue(hand):
	handVal = 0
	aceCount = 0
	for i in range(len(hand)):
		
		if hand[i] == "J" or hand[i] == "Q" or hand[i] == "K":
			handVal += 10
			
		elif hand[i] == "A":
			aceCount += 1
			
		else:
			hand[i] = int(hand[i])
			handVal += hand[i]

	for i in range(aceCount):
		if handVal + 11 > 21:
			handVal += 1
		else:
			handVal += 11
	return handVal

def flipCards(playerHand, dealerHand):
	
	playerValue = handValue(playerHand)
	p = showHand(playerHand)
	
	dealerValue = handValue(dealerHand)
	d = showHand(dealerHand)
	
	if handValue(playerHand) == 21:
		print("BLACKJACK!!!!")

	print(f"\nYour cards add to {playerValue}. Your deck was "+p)
	print(f"\nThe dealer's cards added to {dealerValue}. Their deck was "+d)
	
	if dealerValue > 21 or playerValue > dealerValue:
		print("Congrats. You won.")
	elif playerValue > 21 or dealerValue > playerValue:
		print("Whoops. You just lost all your money.")
	else:
		print("It must have been a tie!")

def play():
	deck, usedCards = getDeck()
	
	playerHand = []
	dealerHand = []
	stay = False
	
	blackJack = True
	
	card, usedCards = hit(deck, usedCards)
	dealerHand.append(card)
	dealerVal = handValue(dealerHand)
	print("The dealer has a "+showHand(dealerHand))
	
	for i in range(2):
		card, usedCards = hit(deck, usedCards)
		playerHand.append(card)
	print("\nYour hand is: "+showHand(playerHand))
	playerVal = handValue(playerHand)
	print(f"Your hand adds up to {playerVal}")
	
	while blackJack:
		if handValue(dealerHand) < 17:
			card, usedCards = hit(deck, usedCards)
			dealerHand.append(card)
			dealerVal = handValue(dealerHand)
		
		if stay:
			break
			
		choice = input("Type hit or stay: ")
		choice = choice.lower()
		
		if choice == "hit":
			card, usedCards = hit(deck, usedCards)
			playerHand.append(card)
			print("\nYour hand is: "+showHand(playerHand))
			print(f"Your hand adds up to {handValue(playerHand)}\n")
			playerVal = handValue(playerHand)
		
		if choice == "stay":
			stay = True
		
		if dealerVal > 21 or playerVal > 21:
			break
	
	flipCards(playerHand, dealerHand)
	#card, usedCards = hit(deck, usedCards)
	#playerHand.append(card)
	
	#showHand(playerHand)
	#handValue(playerHand)	
def main():
	play()
	
if __name__ == "__main__":
	main()
